<?php
$pageTitle = 'Registrasi';
require __DIR__ . '/../layouts/auth_header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="logo-icon">🚦</div>
        <h1>SmartTraffic Cam</h1>
        <p>Daftar sebagai Operator Monitoring</p>
    </div>

    <div class="auth-body-inner">
        <h2>Buat Akun Baru</h2>
        <p class="sub">Isi data di bawah untuk mendaftar sebagai operator.</p>

        <?php if (!empty($data['errors'])): ?>
            <div class="alert alert-danger">
                ❌ <?= implode('<br>', array_map('htmlspecialchars', $data['errors'])) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?= BASE_URL ?>index.php?page=register" novalidate>
            <div class="form-group">
                <label class="form-label">Nama Lengkap <span class="req">*</span></label>
                <input type="text" name="nama" class="form-control"
                       placeholder="Budi Santoso"
                       value="<?= htmlspecialchars($data['nama'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email <span class="req">*</span></label>
                <input type="email" name="email" class="form-control"
                       placeholder="operator@smarttraffic.id"
                       value="<?= htmlspecialchars($data['email'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password <span class="req">*</span></label>
                <input type="password" name="password" class="form-control"
                       placeholder="Minimal 6 karakter" required>
            </div>
            <div class="form-group">
                <label class="form-label">Konfirmasi Password <span class="req">*</span></label>
                <input type="password" name="confirm_password" class="form-control"
                       placeholder="Ulangi password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block btn-lg">
                ✍️ Daftar
            </button>
        </form>
    </div>

    <div class="auth-footer">
        Sudah punya akun?
        <a href="<?= BASE_URL ?>index.php?page=login"><strong>Masuk di sini</strong></a>
    </div>
</div>

<?php require __DIR__ . '/../layouts/auth_footer.php'; ?>
