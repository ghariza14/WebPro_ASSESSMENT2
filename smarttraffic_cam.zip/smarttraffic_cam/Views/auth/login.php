<?php
$pageTitle = 'Login';
require __DIR__ . '/../layouts/auth_header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="logo-icon">🚦</div>
        <h1>SmartTraffic Cam</h1>
        <p>Sistem Monitoring Kemacetan Smart City</p>
    </div>

    <div class="auth-body-inner">
        <h2>Masuk ke Sistem</h2>
        <p class="sub">Gunakan akun operator Anda untuk mengakses dashboard.</p>

        <?php if (!empty($data['errors'])): ?>
            <div class="alert alert-danger">
                ❌ <?= implode('<br>', array_map('htmlspecialchars', $data['errors'])) ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($_SESSION['success']) ?></div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <form method="POST" action="<?= BASE_URL ?>index.php?page=login" novalidate>
            <div class="form-group">
                <label class="form-label">Email <span class="req">*</span></label>
                <input type="email" name="email" class="form-control"
                       placeholder="operator@smarttraffic.id"
                       value="<?= htmlspecialchars($data['email'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password <span class="req">*</span></label>
                <input type="password" name="password" class="form-control"
                       placeholder="Minimal 6 karakter" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block btn-lg">
                🔓 Masuk
            </button>
        </form>
    </div>

    <div class="auth-footer">
        Belum punya akun?
        <a href="<?= BASE_URL ?>index.php?page=register"><strong>Daftar sekarang</strong></a>
    </div>
</div>

<?php require __DIR__ . '/../layouts/auth_footer.php'; ?>
