<?php
$pageTitle  = 'Edit Monitoring';
$activePage = 'laporan';
require __DIR__ . '/../layouts/header.php';

$record  = $data['record'];
$lokasi  = htmlspecialchars($record['lokasi_cctv']      ?? '');
$waktu   = htmlspecialchars(substr($record['waktu_monitoring'] ?? '', 0, 16));
$jumlah  = intval($record['jumlah_kendaraan'] ?? 0);
$deskripsi = htmlspecialchars($record['deskripsi'] ?? '');
$foto    = $record['foto_bukti'] ?? '';
?>

<div class="page-header">
    <div>
        <h1>✏️ Edit Data Monitoring</h1>
        <p>Perbarui rekaman pemantauan CCTV.</p>
    </div>
    <a href="<?= BASE_URL ?>index.php?page=laporan" class="btn btn-secondary">← Kembali</a>
</div>

<?php if (!empty($data['errors'])): ?>
    <div class="alert alert-danger">
        ❌ <strong>Terdapat kesalahan:</strong><br>
        <?= implode('<br>', array_map('htmlspecialchars', $data['errors'])) ?>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class="ch-icon">📝</div>
        <h3>Form Edit Monitoring</h3>
    </div>
    <div class="card-body">
        <form method="POST" action="<?= BASE_URL ?>index.php?page=edit_laporan" enctype="multipart/form-data" novalidate>
            <input type="hidden" name="id" value="<?= $record['id'] ?>">

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="lokasi_cctv">Lokasi CCTV <span class="req">*</span></label>
                    <input type="text" id="lokasi_cctv" name="lokasi_cctv" class="form-control"
                           placeholder="cth: Simpang Lima"
                           value="<?= $lokasi ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="waktu_monitoring">Waktu Monitoring <span class="req">*</span></label>
                    <input type="datetime-local" id="waktu_monitoring" name="waktu_monitoring" class="form-control"
                           value="<?= $waktu ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="jumlah_kendaraan">Jumlah Kendaraan <span class="req">*</span></label>
                    <input type="number" id="jumlah_kendaraan" name="jumlah_kendaraan" class="form-control"
                           min="0" value="<?= $jumlah ?>" required>
                    <div class="form-hint">0–20: Lancar | 21–50: Padat | >50: Macet</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Status Kemacetan (otomatis)</label>
                    <div class="status-info">
                        <div class="si-label">Berdasarkan jumlah kendaraan:</div>
                        <div class="si-value" id="statusPreview"><?= htmlspecialchars($record['status_kemacetan']) ?></div>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Deskripsi Kondisi</label>
                <textarea name="deskripsi" class="form-control"
                          placeholder="Jelaskan kondisi lalu lintas..."><?= $deskripsi ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label">Foto Bukti CCTV</label>
                <?php if ($foto): ?>
                    <div style="margin-bottom:12px; padding:12px; background:var(--accent-light); border-radius:var(--radius); border:1px solid var(--accent);">
                        <div class="text-sm text-muted mb-2">📎 Foto saat ini:</div>
                        <img src="<?= BASE_URL ?>Uploads/<?= htmlspecialchars($foto) ?>"
                             style="height:80px; border-radius:6px; cursor:pointer;"
                             onclick="openModal('<?= BASE_URL ?>Uploads/<?= htmlspecialchars($foto) ?>', 'Foto saat ini')"
                             alt="Foto Saat Ini">
                        <div class="text-sm text-muted mt-1"><?= htmlspecialchars($foto) ?></div>
                    </div>
                <?php endif; ?>
                <label class="file-upload-area" for="foto_bukti">
                    <input type="file" id="foto_bukti" name="foto_bukti" accept=".jpg,.jpeg,.png">
                    <div class="file-upload-icon">🔄</div>
                    <div class="file-upload-text">
                        <strong id="fileLabel">Klik untuk ganti foto (opsional)</strong><br>
                        <?= $foto ? 'Biarkan kosong untuk tetap gunakan foto lama' : 'Format: JPG, JPEG, PNG' ?>
                    </div>
                    <img id="filePreview" class="file-preview" src="" alt="Preview Baru">
                </label>
            </div>

            <hr class="divider">
            <div class="d-flex gap-2 flex-wrap">
                <button type="submit" class="btn btn-primary btn-lg">💾 Perbarui Data</button>
                <a href="<?= BASE_URL ?>index.php?page=laporan" class="btn btn-secondary btn-lg">✕ Batal</a>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
