<?php
$pageTitle  = 'Data Monitoring';
$activePage = 'laporan';
require __DIR__ . '/../layouts/header.php';
?>

<div class="page-header">
    <div>
        <h1>📋 Data Monitoring CCTV</h1>
        <p>Seluruh rekaman pemantauan kemacetan milik akun Anda.</p>
    </div>
    <a href="<?= BASE_URL ?>index.php?page=tambah_laporan" class="btn btn-primary">
        ➕ Tambah Monitoring
    </a>
</div>

<div class="card">
    <div class="card-header">
        <div class="ch-icon">📊</div>
        <h3>Daftar Monitoring — <?= count($data['records']) ?> Data</h3>
    </div>
    <div class="card-body" style="padding:0;">
        <?php if (empty($data['records'])): ?>
            <div class="empty-state">
                <div class="es-icon">🚦</div>
                <h3>Belum ada data monitoring</h3>
                <p>Mulai catat hasil pemantauan CCTV dari berbagai titik kota.</p>
                <a href="<?= BASE_URL ?>index.php?page=tambah_laporan" class="btn btn-primary">➕ Tambah Sekarang</a>
            </div>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Lokasi CCTV</th>
                            <th>Waktu Monitoring</th>
                            <th>Jml. Kendaraan</th>
                            <th>Status</th>
                            <th>Deskripsi</th>
                            <th>Foto Bukti</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data['records'] as $i => $row): ?>
                        <tr>
                            <td class="no-col"><?= $i + 1 ?></td>
                            <td>
                                <div style="font-weight:600;"><?= htmlspecialchars($row['lokasi_cctv']) ?></div>
                            </td>
                            <td style="white-space:nowrap;">
                                <?= date('d/m/Y', strtotime($row['waktu_monitoring'])) ?>
                                <br><span class="text-muted text-sm"><?= date('H:i', strtotime($row['waktu_monitoring'])) ?></span>
                            </td>
                            <td style="text-align:center; font-weight:700; color:var(--primary);">
                                <?= $row['jumlah_kendaraan'] ?>
                            </td>
                            <td>
                                <span class="badge badge-<?= strtolower($row['status_kemacetan']) ?>">
                                    <?= $row['status_kemacetan'] ?>
                                </span>
                            </td>
                            <td style="max-width:200px; font-size:.8rem; color:var(--mid);">
                                <?= htmlspecialchars(mb_strimwidth($row['deskripsi'] ?? '', 0, 80, '…')) ?>
                            </td>
                            <td>
                                <?php if ($row['foto_bukti']): ?>
                                    <img src="<?= BASE_URL ?>Uploads/<?= htmlspecialchars($row['foto_bukti']) ?>"
                                         class="thumb"
                                         onclick="openModal('<?= BASE_URL ?>Uploads/<?= htmlspecialchars($row['foto_bukti']) ?>', '<?= htmlspecialchars($row['lokasi_cctv']) ?>')"
                                         alt="Foto Bukti" title="Klik untuk perbesar">
                                <?php else: ?>
                                    <span class="no-foto">Tidak ada</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-btns">
                                    <a href="<?= BASE_URL ?>index.php?page=edit_laporan&id=<?= $row['id'] ?>"
                                       class="btn btn-success btn-sm" title="Edit">✏️ Edit</a>
                                    <a href="<?= BASE_URL ?>index.php?page=hapus_laporan&id=<?= $row['id'] ?>"
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('Hapus data monitoring ini? File foto juga akan dihapus.')"
                                       title="Hapus">🗑️ Hapus</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
