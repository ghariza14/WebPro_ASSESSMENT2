<?php
$pageTitle  = 'Tambah Monitoring';
$activePage = 'tambah';
require __DIR__ . '/../layouts/header.php';

$lokasi  = htmlspecialchars($data['lokasi']  ?? '');
$waktu   = htmlspecialchars($data['waktu']   ?? date('Y-m-d\TH:i'));
$jumlah  = intval($data['jumlah']  ?? 0);
$deskripsi = htmlspecialchars($data['deskripsi'] ?? '');
?>

<div class="page-header">
    <div>
        <h1>➕ Tambah Data Monitoring</h1>
        <p>Catat hasil pemantauan CCTV dari titik pantau kota.</p>
    </div>
    <a href="<?= BASE_URL ?>index.php?page=laporan" class="btn btn-secondary">← Kembali</a>
</div>

<?php if (!empty($data['errors'])): ?>
    <div class="alert alert-danger">
        ❌ <strong>Terdapat kesalahan:</strong><br>
        <?= implode('<br>', array_map('htmlspecialchars', $data['errors'])) ?>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <div class="ch-icon">📷</div>
        <h3>Form Monitoring CCTV</h3>
    </div>
    <div class="card-body">
        <form method="POST" action="<?= BASE_URL ?>index.php?page=simpan_laporan" enctype="multipart/form-data" novalidate>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="lokasi_cctv">Lokasi CCTV <span class="req">*</span></label>
                    <input type="text" id="lokasi_cctv" name="lokasi_cctv" class="form-control"
                           placeholder="cth: Simpang Lima, Pasar Kota, Depan Terminal"
                           value="<?= $lokasi ?>" required>
                    <div class="form-hint">Nama titik lokasi CCTV dipasang</div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="waktu_monitoring">Waktu Monitoring <span class="req">*</span></label>
                    <input type="datetime-local" id="waktu_monitoring" name="waktu_monitoring" class="form-control"
                           value="<?= $waktu ?>" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label" for="jumlah_kendaraan">Jumlah Kendaraan <span class="req">*</span></label>
                    <input type="number" id="jumlah_kendaraan" name="jumlah_kendaraan" class="form-control"
                           placeholder="0" min="0" value="<?= $jumlah ?>" required>
                    <div class="form-hint">0–20: Lancar | 21–50: Padat | >50: Macet</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Status Kemacetan (otomatis)</label>
                    <div class="status-info">
                        <div class="si-label">Berdasarkan jumlah kendaraan:</div>
                        <div class="si-value lancar" id="statusPreview">Lancar</div>
                    </div>
                    <div class="form-hint">Status ditentukan otomatis oleh sistem</div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="deskripsi">Deskripsi Kondisi</label>
                <textarea id="deskripsi" name="deskripsi" class="form-control"
                          placeholder="Jelaskan kondisi lalu lintas secara singkat..."><?= $deskripsi ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label">Foto Bukti CCTV <span class="req">*</span></label>
                <label class="file-upload-area" for="foto_bukti">
                    <input type="file" id="foto_bukti" name="foto_bukti" accept=".jpg,.jpeg,.png" required>
                    <div class="file-upload-icon">📸</div>
                    <div class="file-upload-text">
                        <strong id="fileLabel">Klik untuk upload foto</strong><br>
                        Format: JPG, JPEG, PNG
                    </div>
                    <img id="filePreview" class="file-preview" src="" alt="Preview">
                </label>
            </div>

            <hr class="divider">
            <div class="d-flex gap-2 flex-wrap">
                <button type="submit" class="btn btn-primary btn-lg">💾 Simpan Data Monitoring</button>
                <a href="<?= BASE_URL ?>index.php?page=laporan" class="btn btn-secondary btn-lg">✕ Batal</a>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
