<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle ?? 'SmartTraffic Cam') ?> — SmartTraffic Cam</title>
<link rel="stylesheet" href="<?= BASE_URL ?>Assets/css/style.css">
</head>
<body>
<div class="app-wrapper">

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div class="brand-icon">🚦</div>
        <h2>SmartTraffic<br>Cam</h2>
        <span>Smart City Monitoring</span>
    </div>

    <div class="sidebar-user">
        <div class="user-avatar"><?= strtoupper(substr($_SESSION['user_nama'] ?? 'U', 0, 1)) ?></div>
        <div class="user-info">
            <div class="user-name"><?= htmlspecialchars($_SESSION['user_nama'] ?? '') ?></div>
            <div class="user-role">Operator</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section-label">Menu</div>
        <a href="<?= BASE_URL ?>index.php?page=dashboard"
           class="nav-item <?= ($activePage ?? '') === 'dashboard' ? 'active' : '' ?>">
            <span class="nav-icon">📊</span> Dashboard
        </a>
        <a href="<?= BASE_URL ?>index.php?page=laporan"
           class="nav-item <?= ($activePage ?? '') === 'laporan' ? 'active' : '' ?>">
            <span class="nav-icon">📋</span> Data Monitoring
        </a>
        <a href="<?= BASE_URL ?>index.php?page=tambah_laporan"
           class="nav-item <?= ($activePage ?? '') === 'tambah' ? 'active' : '' ?>">
            <span class="nav-icon">➕</span> Tambah Monitoring
        </a>

        <hr class="divider" style="margin:12px 20px; border-color:rgba(255,255,255,.07)">
        <div class="nav-section-label">API</div>
        <a href="<?= BASE_URL ?>api/monitoring.php" target="_blank" class="nav-item">
            <span class="nav-icon">🔌</span> RESTful API Docs
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="<?= BASE_URL ?>index.php?page=logout" class="btn btn-danger btn-block btn-sm">
            🚪 Logout
        </a>
    </div>
</aside>

<!-- MAIN -->
<div class="main-content">
<header class="topbar">
    <div class="d-flex align-center gap-2">
        <button onclick="document.getElementById('sidebar').classList.toggle('open')"
                style="display:none; background:none; border:none; font-size:22px; cursor:pointer; color:var(--dark);"
                class="menu-toggle" id="menuToggle">☰</button>
        <div class="topbar-title">
            Smart<span>Traffic</span> Cam
        </div>
    </div>
    <div class="topbar-right">
        <span class="topbar-badge">🏙️ Smart City</span>
        <span style="font-size:.8rem; color:var(--muted);"><?= date('d M Y') ?></span>
    </div>
</header>

<main class="page-content">
<?php if (!empty($_SESSION['success'])): ?>
    <div class="alert alert-success">✅ <?= htmlspecialchars($_SESSION['success']) ?></div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>
<?php if (!empty($_SESSION['error'])): ?>
    <div class="alert alert-danger">❌ <?= htmlspecialchars($_SESSION['error']) ?></div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>
