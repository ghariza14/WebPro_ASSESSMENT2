<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?? 'SmartTraffic Cam' ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>Assets/css/style.css">
</head>
<body class="auth-body">
