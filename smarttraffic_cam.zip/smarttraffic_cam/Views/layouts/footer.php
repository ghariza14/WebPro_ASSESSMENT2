</main>
<footer class="app-footer">
    &copy; <?= date('Y') ?> <span>SmartTraffic Cam</span> — Sistem Monitoring Kemacetan Berbasis CCTV | Smart City
</footer>
</div><!-- .main-content -->
</div><!-- .app-wrapper -->

<!-- Lightbox Modal -->
<div class="modal-overlay" id="imgModal" onclick="closeModal()">
    <div class="modal-box" onclick="event.stopPropagation()">
        <img id="modalImg" src="" alt="Foto Bukti CCTV">
        <p class="mt-2 text-muted text-sm" id="modalCaption"></p>
        <button class="btn btn-secondary mt-2" onclick="closeModal()">✕ Tutup</button>
    </div>
</div>

<script>
// Sidebar toggle on mobile
const toggle = document.getElementById('menuToggle');
if (window.innerWidth <= 900) toggle.style.display = 'block';
window.addEventListener('resize', () => {
    toggle.style.display = window.innerWidth <= 900 ? 'block' : 'none';
});

// Lightbox
function openModal(src, caption) {
    document.getElementById('modalImg').src = src;
    document.getElementById('modalCaption').textContent = caption || '';
    document.getElementById('imgModal').classList.add('open');
}
function closeModal() {
    document.getElementById('imgModal').classList.remove('open');
}

// Status kemacetan otomatis
function updateStatus() {
    const jml = parseInt(document.getElementById('jumlah_kendaraan')?.value || 0);
    const el  = document.getElementById('statusPreview');
    if (!el) return;
    let status, cls;
    if (jml <= 20)      { status = 'Lancar'; cls = 'lancar'; }
    else if (jml <= 50) { status = 'Padat';  cls = 'padat'; }
    else                { status = 'Macet';  cls = 'macet'; }
    el.textContent  = status;
    el.className    = 'si-value ' + cls;
}

document.addEventListener('DOMContentLoaded', () => {
    const jumlahEl = document.getElementById('jumlah_kendaraan');
    if (jumlahEl) {
        jumlahEl.addEventListener('input', updateStatus);
        updateStatus();
    }

    // File preview
    const fileInput = document.getElementById('foto_bukti');
    const preview   = document.getElementById('filePreview');
    if (fileInput && preview) {
        fileInput.addEventListener('change', () => {
            const file = fileInput.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = e => {
                    preview.src     = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
                document.getElementById('fileLabel').textContent = file.name;
            }
        });
    }
});
</script>
</body>
</html>
