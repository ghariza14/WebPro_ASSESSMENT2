<?php
$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
require __DIR__ . '/../layouts/header.php';
?>

<div class="page-header">
    <div>
        <h1>👋 Selamat datang, <span class="gradient-text"><?= htmlspecialchars($_SESSION['user_nama']) ?></span></h1>
        <p>Pantau kondisi lalu lintas kota dari satu dashboard terintegrasi.</p>
    </div>
    <a href="<?= BASE_URL ?>index.php?page=tambah_laporan" class="btn btn-primary">
        ➕ Tambah Monitoring
    </a>
</div>

<!-- STAT CARDS -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon total">📊</div>
        <div>
            <div class="stat-value"><?= $data['total'] ?></div>
            <div class="stat-label">Total Monitoring</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon lancar">✅</div>
        <div>
            <div class="stat-value"><?= $data['lancar'] ?></div>
            <div class="stat-label">Status Lancar</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon padat">⚠️</div>
        <div>
            <div class="stat-value"><?= $data['padat'] ?></div>
            <div class="stat-label">Status Padat</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon macet">🚨</div>
        <div>
            <div class="stat-value"><?= $data['macet'] ?></div>
            <div class="stat-label">Status Macet</div>
        </div>
    </div>
</div>

<!-- LATEST TABLE -->
<div class="card">
    <div class="card-header">
        <div class="ch-icon">🕐</div>
        <div>
            <h3>Data Monitoring Terbaru</h3>
        </div>
        <a href="<?= BASE_URL ?>index.php?page=laporan" class="btn btn-secondary btn-sm" style="margin-left:auto;">
            Lihat Semua →
        </a>
    </div>
    <div class="card-body" style="padding:0;">
        <?php if (empty($data['terbaru'])): ?>
            <div class="empty-state">
                <div class="es-icon">📷</div>
                <h3>Belum ada data monitoring</h3>
                <p>Tambahkan data monitoring CCTV pertama Anda.</p>
                <a href="<?= BASE_URL ?>index.php?page=tambah_laporan" class="btn btn-primary">➕ Tambah Sekarang</a>
            </div>
        <?php else: ?>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Lokasi CCTV</th>
                            <th>Waktu</th>
                            <th>Kendaraan</th>
                            <th>Status</th>
                            <th>Foto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data['terbaru'] as $row): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($row['lokasi_cctv']) ?></strong></td>
                            <td><?= date('d/m/Y H:i', strtotime($row['waktu_monitoring'])) ?></td>
                            <td><?= $row['jumlah_kendaraan'] ?> kend.</td>
                            <td>
                                <span class="badge badge-<?= strtolower($row['status_kemacetan']) ?>">
                                    <?= $row['status_kemacetan'] ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($row['foto_bukti']): ?>
                                    <img src="<?= BASE_URL ?>Uploads/<?= htmlspecialchars($row['foto_bukti']) ?>"
                                         class="thumb"
                                         onclick="openModal('<?= BASE_URL ?>Uploads/<?= htmlspecialchars($row['foto_bukti']) ?>', '<?= htmlspecialchars($row['lokasi_cctv']) ?>')"
                                         alt="Foto">
                                <?php else: ?>
                                    <span class="no-foto">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
