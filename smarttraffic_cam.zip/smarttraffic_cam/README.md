# SmartTraffic Cam 🚦
Sistem Monitoring Kemacetan Berbasis CCTV untuk Smart City

## Cara Install di XAMPP

1. **Copy folder** `smarttraffic_cam` ke `C:\xampp\htdocs\`
2. **Buka phpMyAdmin** → import file `config/setup.sql`
3. **Akses** melalui: `http://localhost/smarttraffic_cam`

## Akun Demo
- Email: `admin@smarttraffic.id`
- Password: `password`

## Struktur Folder
```
smarttraffic_cam/
├── Controllers/        # Controller MVC
├── Models/             # Model MVC
├── Views/              # View MVC
│   ├── auth/           # Login, Register
│   ├── dashboard/      # Dashboard
│   ├── monitoring/     # CRUD Monitoring
│   └── layouts/        # Header, Footer
├── Assets/css/         # File CSS
├── Uploads/            # File upload CCTV
├── api/                # RESTful API
├── config/             # Database, helper, autoload
└── index.php           # Router utama
```

## RESTful API
Base URL: `http://localhost/smarttraffic_cam/api/monitoring.php`

| Method | Endpoint               | Keterangan           |
|--------|------------------------|----------------------|
| GET    | /api/monitoring.php    | Semua data           |
| GET    | /api/monitoring.php?id=1 | Detail by ID       |
| POST   | /api/monitoring.php    | Tambah data          |
| PUT    | /api/monitoring.php?id=1 | Update data        |
| DELETE | /api/monitoring.php?id=1 | Hapus data         |
