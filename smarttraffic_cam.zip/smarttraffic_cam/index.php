<?php
session_start();
define('BASE_URL', '/smarttraffic_cam/');
define('UPLOAD_URL', BASE_URL . 'Uploads/');

require_once __DIR__ . '/config/helpers.php';
require_once __DIR__ . '/config/autoload.php';

$page   = $_GET['page']   ?? 'login';
$action = $_GET['action'] ?? '';

// Routing
switch ($page) {
    // ---- AUTH ----
    case 'login':
        $ctrl = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ctrl->login();
        } else {
            $ctrl->showLogin();
        }
        break;

    case 'register':
        $ctrl = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ctrl->register();
        } else {
            $ctrl->showRegister();
        }
        break;

    case 'logout':
        (new AuthController())->logout();
        break;

    // ---- DASHBOARD ----
    case 'dashboard':
        (new DashboardController())->index();
        break;

    // ---- LAPORAN / MONITORING ----
    case 'laporan':
        (new MonitoringController())->index();
        break;

    case 'tambah_laporan':
        (new MonitoringController())->tambah();
        break;

    case 'simpan_laporan':
        (new MonitoringController())->simpan();
        break;

    case 'edit_laporan':
        $ctrl = new MonitoringController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ctrl->update();
        } else {
            $ctrl->edit();
        }
        break;

    case 'hapus_laporan':
        (new MonitoringController())->hapus();
        break;

    default:
        redirect('index.php?page=login');
}
