<?php
// Autoloader
spl_autoload_register(function ($class) {
    $paths = [
        __DIR__ . '/../Models/' . $class . '.php',
        __DIR__ . '/../Controllers/' . $class . '.php',
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

// Helper: redirect
function redirect($url) {
    header('Location: ' . BASE_URL . $url);
    exit;
}

// Helper: cek login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Helper: require login
function requireLogin() {
    if (!isLoggedIn()) {
        redirect('index.php?page=login');
    }
}

// Helper: tentukan status kemacetan berdasarkan jumlah kendaraan
function tentukanStatus($jumlah) {
    if ($jumlah <= 20) return 'Lancar';
    if ($jumlah <= 50) return 'Padat';
    return 'Macet';
}

// Helper: badge warna status
function statusBadge($status) {
    $map = [
        'Lancar' => 'badge-lancar',
        'Padat'  => 'badge-padat',
        'Macet'  => 'badge-macet',
    ];
    return $map[$status] ?? 'badge-secondary';
}
