-- =====================================================
-- SmartTraffic Cam - Database Setup
-- =====================================================

CREATE DATABASE IF NOT EXISTS smarttraffic_cam CHARACTER SET utf8 COLLATE utf8_general_ci;
USE smarttraffic_cam;

-- Tabel Users
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Monitoring
CREATE TABLE IF NOT EXISTS monitoring (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lokasi_cctv VARCHAR(150) NOT NULL,
    waktu_monitoring DATETIME NOT NULL,
    jumlah_kendaraan INT NOT NULL,
    status_kemacetan ENUM('Lancar','Padat','Macet') NOT NULL,
    deskripsi TEXT,
    foto_bukti VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample user (password: admin123)
INSERT INTO users (nama, email, password) VALUES
('Admin Kota', 'admin@smarttraffic.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
