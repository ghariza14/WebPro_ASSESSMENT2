<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

class MonitoringModel {
    private $conn;

    public function __construct() {
        $this->conn = getConnection();
    }

    public function getAllByUser($user_id) {
        $stmt = $this->conn->prepare("SELECT * FROM monitoring WHERE user_id = ? ORDER BY waktu_monitoring DESC");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getAll() {
        $result = $this->conn->query("SELECT m.*, u.nama FROM monitoring m JOIN users u ON m.user_id = u.id ORDER BY m.waktu_monitoring DESC");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM monitoring WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function getByIdAndUser($id, $user_id) {
        $stmt = $this->conn->prepare("SELECT * FROM monitoring WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $id, $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function create($data) {
        $status = tentukanStatus($data['jumlah_kendaraan']);
        $stmt = $this->conn->prepare(
            "INSERT INTO monitoring (user_id, lokasi_cctv, waktu_monitoring, jumlah_kendaraan, status_kemacetan, deskripsi, foto_bukti) 
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
            "issisis",
            $data['user_id'],
            $data['lokasi_cctv'],
            $data['waktu_monitoring'],
            $data['jumlah_kendaraan'],
            $status,
            $data['deskripsi'],
            $data['foto_bukti']
        );
        return $stmt->execute();
    }

    public function update($id, $data) {
        $status = tentukanStatus($data['jumlah_kendaraan']);
        $stmt = $this->conn->prepare(
            "UPDATE monitoring SET lokasi_cctv=?, waktu_monitoring=?, jumlah_kendaraan=?, status_kemacetan=?, deskripsi=?, foto_bukti=? WHERE id=? AND user_id=?"
        );
        $stmt->bind_param(
            "ssisssii",
            $data['lokasi_cctv'],
            $data['waktu_monitoring'],
            $data['jumlah_kendaraan'],
            $status,
            $data['deskripsi'],
            $data['foto_bukti'],
            $id,
            $data['user_id']
        );
        return $stmt->execute();
    }

    public function delete($id, $user_id) {
        $row = $this->getByIdAndUser($id, $user_id);
        if (!$row) return false;
        // Hapus file
        if ($row['foto_bukti'] && file_exists(__DIR__ . '/../Uploads/' . $row['foto_bukti'])) {
            unlink(__DIR__ . '/../Uploads/' . $row['foto_bukti']);
        }
        $stmt = $this->conn->prepare("DELETE FROM monitoring WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $id, $user_id);
        return $stmt->execute();
    }

    // Dashboard stats
    public function countByUser($user_id) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM monitoring WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc()['total'];
    }

    public function countByStatus($user_id, $status) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM monitoring WHERE user_id = ? AND status_kemacetan = ?");
        $stmt->bind_param("is", $user_id, $status);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc()['total'];
    }

    public function getLatestByUser($user_id, $limit = 5) {
        $stmt = $this->conn->prepare("SELECT * FROM monitoring WHERE user_id = ? ORDER BY waktu_monitoring DESC LIMIT ?");
        $stmt->bind_param("ii", $user_id, $limit);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
