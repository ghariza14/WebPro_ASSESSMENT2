<?php
/**
 * SmartTraffic Cam — RESTful API
 * Endpoint: /smarttraffic_cam/api/monitoring.php
 *
 * GET    /api/monitoring.php           → semua data
 * GET    /api/monitoring.php?id={id}   → detail by id
 * POST   /api/monitoring.php           → tambah data
 * PUT    /api/monitoring.php?id={id}   → update data
 * DELETE /api/monitoring.php?id={id}   → hapus data
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

$conn   = getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$id     = isset($_GET['id']) ? intval($_GET['id']) : null;

// ── Helper responses ──────────────────────────────
function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function notFound() {
    respond(['status' => 'error', 'message' => 'Data tidak ditemukan.'], 404);
}

// ── GET ALL / GET BY ID ───────────────────────────
if ($method === 'GET') {
    if ($id) {
        $stmt = $conn->prepare("SELECT m.*, u.nama AS operator FROM monitoring m JOIN users u ON m.user_id=u.id WHERE m.id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if (!$row) notFound();
        $row['foto_url'] = $row['foto_bukti'] ? '/smarttraffic_cam/Uploads/' . $row['foto_bukti'] : null;
        respond(['status' => 'success', 'data' => $row]);
    } else {
        $result = $conn->query("SELECT m.*, u.nama AS operator FROM monitoring m JOIN users u ON m.user_id=u.id ORDER BY m.waktu_monitoring DESC");
        $rows   = $result->fetch_all(MYSQLI_ASSOC);
        foreach ($rows as &$r) {
            $r['foto_url'] = $r['foto_bukti'] ? '/smarttraffic_cam/Uploads/' . $r['foto_bukti'] : null;
        }
        respond(['status' => 'success', 'total' => count($rows), 'data' => $rows]);
    }
}

// ── POST (create) ─────────────────────────────────
if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    $user_id  = intval($body['user_id']          ?? 0);
    $lokasi   = trim($body['lokasi_cctv']         ?? '');
    $waktu    = trim($body['waktu_monitoring']     ?? '');
    $jumlah   = intval($body['jumlah_kendaraan']  ?? 0);
    $deskripsi= trim($body['deskripsi']           ?? '');
    $foto     = trim($body['foto_bukti']          ?? '');

    if (!$user_id || !$lokasi || !$waktu) {
        respond(['status' => 'error', 'message' => 'Field user_id, lokasi_cctv, dan waktu_monitoring wajib diisi.'], 422);
    }

    $status = tentukanStatus($jumlah);

    $stmt = $conn->prepare("INSERT INTO monitoring (user_id, lokasi_cctv, waktu_monitoring, jumlah_kendaraan, status_kemacetan, deskripsi, foto_bukti) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("issisis", $user_id, $lokasi, $waktu, $jumlah, $status, $deskripsi, $foto);

    if ($stmt->execute()) {
        respond(['status' => 'success', 'message' => 'Data berhasil ditambahkan.', 'id' => $conn->insert_id], 201);
    } else {
        respond(['status' => 'error', 'message' => 'Gagal menyimpan data.'], 500);
    }
}

// ── PUT/PATCH (update) ────────────────────────────
if (in_array($method, ['PUT', 'PATCH'])) {
    if (!$id) respond(['status' => 'error', 'message' => 'Parameter id diperlukan.'], 400);

    $body = json_decode(file_get_contents('php://input'), true) ?? [];

    $check = $conn->prepare("SELECT id FROM monitoring WHERE id=?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) notFound();

    $existing = $conn->query("SELECT * FROM monitoring WHERE id=$id")->fetch_assoc();

    $lokasi    = trim($body['lokasi_cctv']        ?? $existing['lokasi_cctv']);
    $waktu     = trim($body['waktu_monitoring']    ?? $existing['waktu_monitoring']);
    $jumlah    = intval($body['jumlah_kendaraan']  ?? $existing['jumlah_kendaraan']);
    $deskripsi = trim($body['deskripsi']           ?? $existing['deskripsi']);
    $foto      = trim($body['foto_bukti']          ?? $existing['foto_bukti']);
    $status    = tentukanStatus($jumlah);

    $stmt = $conn->prepare("UPDATE monitoring SET lokasi_cctv=?, waktu_monitoring=?, jumlah_kendaraan=?, status_kemacetan=?, deskripsi=?, foto_bukti=? WHERE id=?");
    $stmt->bind_param("ssisssi", $lokasi, $waktu, $jumlah, $status, $deskripsi, $foto, $id);

    if ($stmt->execute()) {
        respond(['status' => 'success', 'message' => 'Data berhasil diperbarui.']);
    } else {
        respond(['status' => 'error', 'message' => 'Gagal memperbarui data.'], 500);
    }
}

// ── DELETE ────────────────────────────────────────
if ($method === 'DELETE') {
    if (!$id) respond(['status' => 'error', 'message' => 'Parameter id diperlukan.'], 400);

    $row = $conn->query("SELECT * FROM monitoring WHERE id=$id")->fetch_assoc();
    if (!$row) notFound();

    // Hapus file
    if ($row['foto_bukti']) {
        $path = __DIR__ . '/../Uploads/' . $row['foto_bukti'];
        if (file_exists($path)) unlink($path);
    }

    $stmt = $conn->prepare("DELETE FROM monitoring WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        respond(['status' => 'success', 'message' => 'Data berhasil dihapus.']);
    } else {
        respond(['status' => 'error', 'message' => 'Gagal menghapus data.'], 500);
    }
}

respond(['status' => 'error', 'message' => 'Method tidak diizinkan.'], 405);
