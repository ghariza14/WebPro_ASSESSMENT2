<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>API Docs — SmartTraffic Cam</title>
<style>
:root { --primary:#F97316; --accent:#FBBF24; --dark:#1C1917; }
body { font-family:'Segoe UI',sans-serif; background:#0F0F0F; color:#E5E5E5; margin:0; padding:24px; }
h1   { color:var(--accent); }
h2   { color:var(--primary); border-bottom:1px solid #333; padding-bottom:8px; margin-top:32px; }
.ep  { background:#1A1A1A; border-left:4px solid var(--primary); padding:14px 18px; border-radius:6px; margin:12px 0; font-family:monospace; }
.method { display:inline-block; padding:2px 10px; border-radius:4px; font-weight:700; font-size:.8rem; margin-right:8px; }
.GET    { background:#22C55E; color:#fff; }
.POST   { background:#3B82F6; color:#fff; }
.PUT    { background:#F59E0B; color:#fff; }
.DELETE { background:#EF4444; color:#fff; }
code { background:#252525; padding:2px 6px; border-radius:4px; font-size:.85rem; }
</style>
</head>
<body>
<h1>🔌 SmartTraffic Cam — RESTful API</h1>
<p style="color:#aaa;">Base URL: <code>http://localhost/smarttraffic_cam/api/monitoring.php</code></p>

<h2>Endpoints</h2>

<div class="ep"><span class="method GET">GET</span> <code>/api/monitoring.php</code> — Semua data monitoring</div>
<div class="ep"><span class="method GET">GET</span> <code>/api/monitoring.php?id={id}</code> — Detail monitoring by ID</div>
<div class="ep"><span class="method POST">POST</span> <code>/api/monitoring.php</code> — Tambah data monitoring</div>
<div class="ep"><span class="method PUT">PUT</span> <code>/api/monitoring.php?id={id}</code> — Update data monitoring</div>
<div class="ep"><span class="method DELETE">DELETE</span> <code>/api/monitoring.php?id={id}</code> — Hapus data monitoring</div>

<h2>POST Body (JSON)</h2>
<pre style="background:#1A1A1A; padding:16px; border-radius:8px;">
{
  "user_id": 1,
  "lokasi_cctv": "Simpang Lima",
  "waktu_monitoring": "2024-06-01 08:30:00",
  "jumlah_kendaraan": 35,
  "deskripsi": "Kondisi padat menjelang jam masuk kantor",
  "foto_bukti": "nama_file.jpg"
}
</pre>

<h2>Status Kemacetan (otomatis)</h2>
<ul>
  <li>0–20 kendaraan → <strong style="color:#22C55E">Lancar</strong></li>
  <li>21–50 kendaraan → <strong style="color:#F59E0B">Padat</strong></li>
  <li>&gt;50 kendaraan → <strong style="color:#EF4444">Macet</strong></li>
</ul>

<p style="color:#555; margin-top:48px;">SmartTraffic Cam API &copy; <?= date('Y') ?></p>
</body>
</html>
