<?php
require_once __DIR__ . '/../Models/MonitoringModel.php';
require_once __DIR__ . '/../config/helpers.php';

class MonitoringController {
    private $model;
    private $uploadDir;

    public function __construct() {
        $this->model     = new MonitoringModel();
        $this->uploadDir = __DIR__ . '/../Uploads/';
    }

    public function index() {
        requireLogin();
        $user_id = $_SESSION['user_id'];
        $data['records'] = $this->model->getAllByUser($user_id);
        require __DIR__ . '/../Views/monitoring/index.php';
    }

    public function tambah() {
        requireLogin();
        $data = [];
        require __DIR__ . '/../Views/monitoring/tambah.php';
    }

    public function simpan() {
        requireLogin();
        $errors = [];
        $user_id        = $_SESSION['user_id'];
        $lokasi         = trim($_POST['lokasi_cctv'] ?? '');
        $waktu          = $_POST['waktu_monitoring'] ?? '';
        $jumlah         = intval($_POST['jumlah_kendaraan'] ?? 0);
        $deskripsi      = trim($_POST['deskripsi'] ?? '');
        $foto_bukti     = '';

        if (empty($lokasi))  $errors[] = 'Lokasi CCTV wajib diisi.';
        if (empty($waktu))   $errors[] = 'Waktu monitoring wajib diisi.';
        if ($jumlah < 0)     $errors[] = 'Jumlah kendaraan tidak valid.';

        // Upload file
        if (!empty($_FILES['foto_bukti']['name'])) {
            $file     = $_FILES['foto_bukti'];
            $allowed  = ['jpg','jpeg','png'];
            $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) {
                $errors[] = 'Format file tidak valid. Hanya jpg, jpeg, png.';
            } else {
                $filename   = 'cctv_' . time() . '_' . uniqid() . '.' . $ext;
                if (!move_uploaded_file($file['tmp_name'], $this->uploadDir . $filename)) {
                    $errors[] = 'Upload file gagal.';
                } else {
                    $foto_bukti = $filename;
                }
            }
        } else {
            $errors[] = 'Foto bukti wajib diupload.';
        }

        if (!$errors) {
            $this->model->create([
                'user_id'         => $user_id,
                'lokasi_cctv'     => $lokasi,
                'waktu_monitoring'=> $waktu,
                'jumlah_kendaraan'=> $jumlah,
                'deskripsi'       => $deskripsi,
                'foto_bukti'      => $foto_bukti,
            ]);
            $_SESSION['success'] = 'Data monitoring berhasil ditambahkan.';
            redirect('index.php?page=laporan');
        }

        $data = compact('errors', 'lokasi', 'waktu', 'jumlah', 'deskripsi');
        require __DIR__ . '/../Views/monitoring/tambah.php';
    }

    public function edit() {
        requireLogin();
        $id      = intval($_GET['id'] ?? 0);
        $user_id = $_SESSION['user_id'];
        $record  = $this->model->getByIdAndUser($id, $user_id);
        if (!$record) {
            $_SESSION['error'] = 'Data tidak ditemukan.';
            redirect('index.php?page=laporan');
        }
        $data = ['record' => $record];
        require __DIR__ . '/../Views/monitoring/edit.php';
    }

    public function update() {
        requireLogin();
        $id      = intval($_POST['id'] ?? 0);
        $user_id = $_SESSION['user_id'];
        $errors  = [];

        $lokasi     = trim($_POST['lokasi_cctv'] ?? '');
        $waktu      = $_POST['waktu_monitoring'] ?? '';
        $jumlah     = intval($_POST['jumlah_kendaraan'] ?? 0);
        $deskripsi  = trim($_POST['deskripsi'] ?? '');

        if (empty($lokasi)) $errors[] = 'Lokasi CCTV wajib diisi.';
        if (empty($waktu))  $errors[] = 'Waktu monitoring wajib diisi.';
        if ($jumlah < 0)    $errors[] = 'Jumlah kendaraan tidak valid.';

        $record = $this->model->getByIdAndUser($id, $user_id);
        if (!$record) {
            $_SESSION['error'] = 'Data tidak ditemukan.';
            redirect('index.php?page=laporan');
        }

        $foto_bukti = $record['foto_bukti'];

        // Upload file baru jika ada
        if (!empty($_FILES['foto_bukti']['name'])) {
            $file    = $_FILES['foto_bukti'];
            $allowed = ['jpg','jpeg','png'];
            $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) {
                $errors[] = 'Format file tidak valid. Hanya jpg, jpeg, png.';
            } else {
                $filename = 'cctv_' . time() . '_' . uniqid() . '.' . $ext;
                if (!move_uploaded_file($file['tmp_name'], $this->uploadDir . $filename)) {
                    $errors[] = 'Upload file gagal.';
                } else {
                    // hapus file lama
                    if ($foto_bukti && file_exists($this->uploadDir . $foto_bukti)) {
                        unlink($this->uploadDir . $foto_bukti);
                    }
                    $foto_bukti = $filename;
                }
            }
        }

        if (!$errors) {
            $this->model->update($id, [
                'user_id'         => $user_id,
                'lokasi_cctv'     => $lokasi,
                'waktu_monitoring'=> $waktu,
                'jumlah_kendaraan'=> $jumlah,
                'deskripsi'       => $deskripsi,
                'foto_bukti'      => $foto_bukti,
            ]);
            $_SESSION['success'] = 'Data monitoring berhasil diperbarui.';
            redirect('index.php?page=laporan');
        }

        $data = ['record' => array_merge($record, compact('lokasi','waktu','jumlah','deskripsi')), 'errors' => $errors];
        require __DIR__ . '/../Views/monitoring/edit.php';
    }

    public function hapus() {
        requireLogin();
        $id      = intval($_GET['id'] ?? 0);
        $user_id = $_SESSION['user_id'];
        if ($this->model->delete($id, $user_id)) {
            $_SESSION['success'] = 'Data monitoring berhasil dihapus.';
        } else {
            $_SESSION['error'] = 'Gagal menghapus data.';
        }
        redirect('index.php?page=laporan');
    }
}
