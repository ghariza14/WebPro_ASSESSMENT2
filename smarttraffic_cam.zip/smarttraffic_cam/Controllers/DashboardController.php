<?php
require_once __DIR__ . '/../Models/MonitoringModel.php';
require_once __DIR__ . '/../config/helpers.php';

class DashboardController {
    private $model;

    public function __construct() {
        $this->model = new MonitoringModel();
    }

    public function index() {
        requireLogin();
        $user_id = $_SESSION['user_id'];
        $data = [
            'total'   => $this->model->countByUser($user_id),
            'lancar'  => $this->model->countByStatus($user_id, 'Lancar'),
            'padat'   => $this->model->countByStatus($user_id, 'Padat'),
            'macet'   => $this->model->countByStatus($user_id, 'Macet'),
            'terbaru' => $this->model->getLatestByUser($user_id, 5),
        ];
        require __DIR__ . '/../Views/dashboard/index.php';
    }
}
