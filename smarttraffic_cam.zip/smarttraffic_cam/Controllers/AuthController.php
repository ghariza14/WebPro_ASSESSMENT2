<?php
require_once __DIR__ . '/../Models/UserModel.php';
require_once __DIR__ . '/../config/helpers.php';

class AuthController {
    private $model;

    public function __construct() {
        $this->model = new UserModel();
    }

    public function showLogin() {
        require __DIR__ . '/../Views/auth/login.php';
    }

    public function showRegister() {
        require __DIR__ . '/../Views/auth/register.php';
    }

    public function login() {
        $errors = [];
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email tidak valid.';
        }
        if (strlen($password) < 6) {
            $errors[] = 'Password minimal 6 karakter.';
        }

        if (!$errors) {
            $user = $this->model->findByEmail($email);
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_nama'] = $user['nama'];
                $_SESSION['user_email']= $user['email'];
                redirect('index.php?page=dashboard');
            } else {
                $errors[] = 'Email atau password salah.';
            }
        }

        $data = ['errors' => $errors, 'email' => $email];
        require __DIR__ . '/../Views/auth/login.php';
    }

    public function register() {
        $errors = [];
        $nama     = trim($_POST['nama'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if (empty($nama))  $errors[] = 'Nama wajib diisi.';
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email tidak valid.';
        if (strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
        if ($password !== $confirm) $errors[] = 'Konfirmasi password tidak cocok.';

        if (!$errors) {
            if ($this->model->emailExists($email)) {
                $errors[] = 'Email sudah terdaftar.';
            } else {
                $this->model->create($nama, $email, $password);
                $_SESSION['success'] = 'Registrasi berhasil! Silakan login.';
                redirect('index.php?page=login');
            }
        }

        $data = compact('errors', 'nama', 'email');
        require __DIR__ . '/../Views/auth/register.php';
    }

    public function logout() {
        session_destroy();
        redirect('index.php?page=login');
    }
}
